# Atualização do Live-Auto-Log

## Instalação no GitHub

1. Extraia o ZIP. Ele contém os arquivos alterados e novos. A pasta `.github/workflows` deve ficar na raiz do repositório, ao lado de `persistent_login.py`, `interface_jogo.py`, `comandos_jogo.py`, `contas.js`, `mencoes.js` e `furni.js`.
2. No GitHub Desktop, abra o clone de MauricioFFJ/Live-Auto-Log e use **Fetch origin** e **Pull origin**. Crie uma branch a partir de main. Copie o conteúdo extraído para a raiz do clone aceitando a substituição dos arquivos de mesmo nome. Faça commit, publique a branch e abra um pull request para main.
3. Revise a lista de arquivos do pull request. Se main já recebeu mudanças em persistent_login.py ou nos workflows de comando desde o seu ZIP, concilie essas diferenças antes do merge.
4. Após o merge, os próximos logins carregam o código novo. Para testar assim que publicar, coloque `HABILITAR_REINICIO` em `false` nas **Settings → Secrets and variables → Actions → Variables**, cancele os logins antigos e aguarde seu término. Volte a variável para `true`, abra **Actions → Persistent Login (Contas 1-5) → Run workflow** e aguarde o monitor de comandos iniciar no log.
5. Abra **(Comando) Falar frase**, informe apenas `1` e uma frase curta. Confira o balão na conta correta. Depois, execute **Iniciar todos os logins persistentes**. O iniciador verifica grupos ativos e despacha os grupos restantes. Os comandos de publicação usam `contents: write`; o iniciador usa `actions: write`. O monitor existente precisa ter permissão efetiva para despachar workflows.
6. Para reverter, reverta o commit de merge e repita a troca dos runners do passo 4. As credenciais continuam nos secrets existentes.

## Selecionar contas

Em cada workflow de comando, digite números de 1 a 50, por exemplo `1, 3, 17`. Marque **Todas as contas** para atingir as 50. Os dez runners continuam hospedando cinco contas cada. O agendamento antigo de carinhos ainda lê `TRATAR_CARINHOS_AUTO` e `TRATAR_CARINHOS_GRUPOS`. O intervalo de consulta vem de cada YAML de login. No grupo 01–05, ele é de 20 segundos.

## Comandos pelo jogo

Com o destinatário online no quarto, a sintaxe testada no chat da conta principal foi `@Whisper talk Olá amigos, bom dia.`. O monitor tenta reconhecer a notificação que começa exatamente por **Solitudine mencionou você:**. O recebimento foi confirmado na Central de Notificações de Whisper. O leitor remove o @ da conta e o convite para ir ao quarto. A captura pelo runner ainda precisa ser testada. Ao abrir a central, os registros que já estavam visíveis formam a base para comparação. Se o cliente exibir outro tipo de aviso ou texto, o seletor em `mencoes.js` precisa ser ajustado.

| Texto depois do nome da conta | Ação solicitada |
| --- | --- |
| `talk Olá amigos, bom dia.` | Enviar a frase no chat |
| `respect Solitudine` | Usar o fluxo de respeito existente |
| `carinhos` | Tratar plantas e acariciar mascotes pelo chooser |
| `visitar Solitudine \| Nome do quarto` | Pesquisar o dono e o quarto |
| `hotel` | Clicar no H |
| `cafofo` | Clicar na casa disponível ou abrir o H, esperar um segundo e procurar a casa |
| `entrargrupo` / `sairgrupo` | Clicar no botão correspondente quando estiver visível |
| `amigos` | Abrir a lista de amigos e aceitar pedidos disponíveis |
| `voucher MAISBEIJOS300` | Abrir a Loja e tentar resgatar o código |

## Cookie e dados

Em **(Comando) Cookie e dados**, escolha **Cookie**, **Primeiro dado**, **Todos os dados** ou **CANCELAR**. O workflow salva a escolha por conta em `commands/furni-state.json`. O monitor lê o arquivo no início e após alterações. Ao reconectar, a conta retoma a busca quando o quarto estiver disponível. O modo todos segue a ordem das linhas do furni e verifica o ID do mobi no painel antes de usar. Mantenha habilitada a exibição das coordenadas e do ID do mobi. O temporizador pede uma ação a cada 100 ms. A taxa efetiva depende da disponibilidade do painel e do navegador. Para parar, publique **CANCELAR** para as contas desejadas.

## Voucher e calendário

`VOUCHER_ATIVO = False` em `interface_jogo.py` desativa o resgate manual e automático depois que os runners carregam a alteração. O monitor procura avisos com “código:” ou “voucher:” seguido de código alfanumérico contendo pelo menos um dígito. O botão **Gerar** recebe clique nativo do Selenium. A resposta precisa aparecer para que a rotina tente fechar as janelas. Avisos com outro formato precisam de uma amostra real. O calendário procura um botão **Abrir** durante os primeiros 90 segundos de sessão.

## Cobertura de teste

No Live VIP, o balão de Solitudine exibiu a menção de teste. O chooser listou Whisper e mascotes. O furni exibiu 751 itens, dos quais quatro Blue Dice com IDs distintos. O teste selecionou o primeiro e clicou em Usar. A Loja mostrou o campo Gerar código na aba Destaque e Edição Limitada em Economia. Na janela anônima, Whisper recebeu a menção no histórico, entrou no grupo e abriu a confirmação de saída. O teste manual ofereceu 33 mobis a Solitudine em seis lotes. Depois dos aceites, a aba Mobis de Whisper apareceu vazia. O comando :coords registrou movimento de (42, 4) a (42, 7). A resposta automática, o resgate, o grupo, as amizades, o calendário e a retomada do loop ainda precisam de teste de ponta a ponta nos runners. Os scripts internos dos dez workflows foram exercitados localmente com uma API simulada e o Python foi compilado.

## Raros aos domingos

Deixe **Persistent Login (Contas 1-5)** rodando antes das 16h de Brasília. As contas 1 e 2 consultam Economia → Edição Limitada. Se a lista vier vazia, o monitor espera e consulta outra vez. Cada conta percorre as ofertas na ordem da loja, uma unidade por vez. Ao terminar a lista, começa outra volta pelos itens disponíveis. Só marca um item como esgotado quando lê **ESGOTADO**. Falta de saldo e falha de leitura ficam no log. Às 16h10, o monitor relê a seleção para a abertura VIP. Contas sem VIP continuam nos itens comuns que viram na primeira etapa. Se a loja fechar, o monitor tenta reabri-la. Depois de um reinício, uma conta comum que perdeu o histórico das ofertas das 16h pode ignorar ofertas às 16h10. Os controles da venda real precisam ser validados durante o evento.

## Câmbio, reciclagem e caminhada

Use o workflow **Comprar câmbios** ou envie, por exemplo, `@Whisper cambio Duckets` ou `@Whisper cambio Diamantes`. A conta prioriza o maior valor de face que seu saldo permite, confere preço e moeda no catálogo e aguarda o débito. Entre compras confirmadas, espera pelo menos 1,05 s.

Use **Reciclar no Furni-Matic** ou `@Whisper reciclar 2` para pedir duas reciclagens. Cada ciclo usa oito Caixas Recicláveis, uma por segundo. Se faltarem caixas, a rotina procura o pacote de 16 e confere a moeda antes de comprar. Compras de caixas exigem Duckets. Para câmbio e reciclagem por menção, abra a Central de Notificações em Para você antes do envio.

Use **Andar no quarto** ou `@Whisper andar mobi 12345` (ID do furni) ou `@Whisper andar frente Solitudine`. Substitua Whisper pelo nome de qualquer conta. A caminhada depende de o cliente expor o mapa, a orientação e a projeção da casa na tela. Se a geometria estiver indisponível, o comando registra erro. A navegação relativa ainda é experimental.

Na Whisper, o teste manual confirmou o pacote de 16 por 1.800 Duckets e a recompensa por oito caixas. O câmbio de 2.500 Duckets aparecia por 2.580. A seleção de moeda e a reciclagem automáticas ainda precisam de validação no runner.

## Negociar com Solitudine

Use o workflow **Negociar com Solitudine** ou envie `@Whisper trade`. A conta abre o chooser, procura Solitudine, confere os participantes, oferece os lotes e acompanha o total aceito. Solitudine deve aceitar e confirmar pelo seu lado. Para trade por menção, a Central de Notificações deve estar aberta em Para você antes do envio. O monitor tenta abrir o atalho quando o reconhece e lê apenas registros novos com remetente separado. O fluxo foi percorrido manualmente no Chrome; o código para o runner ainda precisa de um teste integrado. Se houver uma troca aberta, confira essa janela antes de enviar outro comando.

## Respeitar, tratar e dar carinho

Copie também chooser_acoes.js, respeitos.js e plantas_pets.js para a raiz. Os workflows existentes e as menções respect e carinhos usam os mesmos comandos. O log mostra os dois lotes de respeito e as linhas de mascotes processadas. Uma confirmação de compra é permitida por execução.
